import requests
from lxml import etree

headers = {
    'user-agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36 Edg/131.0.0.0'}
def get_first_text(list):
    try:
        return list[0].strip()
    except:
         return ""
import pandas as pd
df=pd.DataFrame(columns=["序号","标题","链接","导演","评分","评价人数","简介"])

urls = ['https://movie.douban.com/top250?start={}&filter='.format(str(i*25)) for i in range(10)]
count =1
for url in urls:
    res = requests.get(url=url,headers=headers)
    html = etree.HTML(res.text)
    lis = html.xpath('//*[@id="content"]/div/div[1]/ol/li')

    for li in lis:
        title = get_first_text(li.xpath('./div/div[2]/div[1]/a/span[1]/text()'))
        src = get_first_text(li.xpath('./div/div[2]/div[1]/a/@href'))
        dictor = get_first_text(li.xpath('./div/div[2]/div[2]/p[1]/text()'))
        score = get_first_text(li.xpath('./div/div[2]/div[2]/div/span[2]/text()'))
        comment = get_first_text(li.xpath('./div/div[2]/div[2]/div/span[4]/text()'))
        summary = get_first_text(li.xpath('./div/div[2]/div[2]/p[2]/span/text()'))
        print(count,title,src,dictor,score,comment, summary)
        df.loc[len(df.index)]=[count,title,src,dictor,score,comment,summary]
        count += 1
df.to_excel("豆瓣电影top250数据.xlsx",sheet_name="豆瓣电影top250数据",na_rep="")
print("excel文件已经生成！")